module.exports = {
    localUrl: 'mongodb://localhost/sleep'
};
